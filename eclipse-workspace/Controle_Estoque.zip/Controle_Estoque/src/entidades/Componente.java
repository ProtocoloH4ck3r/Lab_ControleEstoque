package entidades;

public class Componente {
	private int id;
	private String nome;
	private int quantidade;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public void aumentarQuantidade(int quantidade) {
		this.quantidade += quantidade;
	}
	public void diminuirQuantidade(int quantidade) {
		this.quantidade -= quantidade;
	}
	
	
	
	
}
